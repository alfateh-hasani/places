@extends('layouts.master')
@push('css')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <style>
        iframe{
            width: 100%;
            height: 100% !important;
        }
        .flatpickr-day {
            width: 30px;  
            height: 30px; 
            line-height: 30px;  
            margin:3px  ;
        }
        span.flatpickr-day.selected{
            background: #EF552C !important;
            color: #fff !important;
            border-color: #EF552C !important;
        }
    </style>

        
@endpush
@section('content')

<section class="detail"> 
    <div class="py-0 lg:py-10 container relative">
        <h1 class="rtl:float-right float-left font-semibold text-2xl hidden lg:block text-title">
            {{ $apartment->ml('name') }}
        </h1>
        <div class="rtl:float-left float-right absolute lg:relative z-10 right-3 lg:right-0 top-4 lg:top-0">
            <a  class="bg-blackopacity inline-block py-1 ml-1 lg:py-2 px-0 w-8 h-8 lg:w-auto lg:h-auto lg:px-4 bg-sort rounded-full text-center lg:rounded-md hover:bg-filteritem ease-in-out duration-300">
                <img src="{{asset('assets/img/share.svg')}}" class="inline-block rtl:ml-0 rtl:lg:ml-2 mr-0 lg:mr-2 h-4" />
                <span class="hidden lg:inline">
                    {{__('apartment.share')}}
                </span>
            </a>
            <a href="javascript:void(0);" onclick="toggleFavorite({{ $apartment->id }})" class="bg-blackopacity inline-block py-1 ml-1 lg:py-2 px-0 w-8 h-8 lg:w-auto lg:h-auto lg:px-4 bg-sort rounded-full text-center lg:rounded-md hover:bg-filteritem ease-in-out duration-300">
                @if ($apartment->is_favorite)
                    <button class="absolute w-6 h-5 top-4 left-4 rtl:right-4 rtl:left-auto bg-contain favorite favorite-active ease-in-out duration-300"></button>
                @else
                    <img src="{{ asset('assets/img/favoritee.svg') }}" class="inline-block rtl:ml-0 rtl:lg:ml-2 mr-0 lg:mr-2 h-4" />

                
                    
                @endif
                <span class="hidden lg:inline">
                    {{ __('apartment.favorite') }}
                </span>
            </a>
            
            
        </div>
        <div class="lg:hidden absolute z-10 left-3 top-4">
            <a class="inline-block py-1 ml-1 px-0 w-8 h-8 bg-sort rounded-full text-center hover:bg-filteritem ease-in-out duration-300">
                <img src="{{asset('assets/img/back-arrow.svg') }}" class="inline-block rtl:ml-0 rtl:lg:ml-2 mr-0 lg:mr-2 h-3" />
            </a>
        </div>
        <div class="clear-both"></div>
    </div>
    <div class="container relative">
        <div class="hidden sm:grid photos grid-cols-4 gap-4 max-w-full rounded-xl overflow-hidden h-[256px] xl:h-[456px] banner-side ease-in-out duration-300">
            
            @if ($apartment->getMedia('image'))
                @foreach ($apartment->getMedia('image') as $key=> $photo)
                    <div>
                        <a data-fancybox="banner" href="{{ $photo->getUrl('grid') }}" class="relative block">
                            <img class="{{$key==0?'w-full h-[256px] xl:h-[456px] object-cover'  :'w-full h-[120px] xl:h-[220px] object-cover'}} " src="{{ $photo->getUrl('grid') }}" />
                            
                        </a>
                </div>
                @endforeach
            @endif 
        </div>
        <div class="buttons absolute z-10 right-4 bottom-4 hidden lg:block">
 
            <button class="bg-white rounded-md py-2 px-3 shadow-lg ml-2 cursor-pointer photo-button"><img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/photo.svg')}}" />
                Show All Photos
            </button>
        </div>
    </div>
    <div class="relative">
        <div class="block sm:hidden photos h-[256px] banner-side ease-in-out duration-300">
            <div>
                <a data-fancybox="banner" href="https://www.youtube.com/watch?v=LXb3EKWsInQ" class="relative block video">
                    <button class="absolute"><img class="w-10 ease-in-out duration-300" src="{{asset('assets/img/video-white.svg')}}" /></button>
                    <img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" />
                </a>
            </div>
            <div><a data-fancybox="banner" href="{{asset('assets/img/slider.png')}}" class="relative block">
                <img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" /></a></div>
            <div><a data-fancybox="banner" href="{{asset('assets/img/slider.png')}}" class="relative block"><img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" /></a></div>
            <div><a data-fancybox="banner" href="{{asset('assets/img/slider.png')}}" class="relative block"><img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" /></a></div>
            <div><a data-fancybox="banner" href="{{asset('assets/img/slider.png')}}" class="relative block"><img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" /></a></div>
            <div><a data-fancybox="banner" href="{{asset('assets/img/slider.png')}}" class="relative block"><img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" /></a></div>
            <div><a data-fancybox="banner" href="{{asset('assets/img/slider.png')}}" class="relative block"><img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" /></a></div>
            <div><a data-fancybox="banner" href="{{asset('assets/img/slider.png')}}" class="relative block"><img class="w-full h-[256px] object-cover" src="{{asset('assets/img/slider.png')}}" /></a></div>
        </div>
    </div>
</section>

<section class="location mt-5 lg:mt-8 mb-0 lg:mb-12">
    <div class="container">
        <div class="float-left rtl:float-right rtl:ml-5 mr-5 lg:hidden mb-3 lg:mb-0">
            <h1 class="float-left rtl:float-right font-semibold text-xl text-title">
                {{ $apartment->ml('name') }}
            </h1>
        </div>
        <div class="float-left rtl:float-right rtl:ml-5 mr-5 w-full lg:w-auto mb-3 lg:mb-0">
            <img class="inline-block mr-2 rtl:ml-2 -translate-y-1" src="{{asset('assets/img/location.svg')}}" />
            <p class="inline-block font-normal text-xl text-title">
                {{ $apartment->building->city->ml('name') }}
            </p>
        </div>
        <div class="float-left rtl:float-right mr-5 w-full lg:w-auto mb-3 lg:mb-0">
            <img class="inline-block mr-2 rtl:ml-2 -translate-y-0.5" src="{{asset('assets/img/star.svg')}}" />
            <p class="inline-block font-normal text-base text-reviews">
                {{ $apartment->rating }}
            </p>
        </div>
        <div class="float-left rtl:float-right mr-5 rtl:ml-5 w-full lg:w-auto mb-3 lg:mb-0">
            <img class="inline-block mr-2 rtl:ml-2 -translate-y-0.5" src="{{asset('assets/img/feature-3.svg')}}" />
            <p class="inline-block font-normal text-base text-reviews">  

                {{__('apartment.area'). $apartment->area }} <sup></sup>
            </p>
        </div>
        <p class="float-right rtl:float-left font-normal text-xl text-title w-full lg:w-auto">
            {{__('apartment.adults_count'). ' ( '.$apartment->adults_count}} )  /
            {{__('apartment.children_count'). ' ( '.$apartment->children_count}}) 
        </p>
        <div class="clear-both"></div>
        <ul class="mt-5 lg:hidden">
            <li>
                <a class="block border border-filterborder py-3 px-4 rounded-lg mb-2 hover:bg-filterborder ease-in-out duration-300">
                    <img class="inline-block" src="{{asset('assets/img/payment-1.png')}}" />
                    <p class="inline-block ml-4 font-normal text-sm text-title">Pay In 4. No Interest, No Fees.</p>
                </a>
            </li>
            <li>
                <a class="block border border-filterborder py-3 px-4 rounded-lg mb-2 hover:bg-filterborder ease-in-out duration-300">
                    <img class="inline-block" src="{{asset('assets/img/payment-2.png')}}" />
                    <p class="inline-block ml-4 font-normal text-sm text-title">Pay In 4. No Interest, No Fees.</p>
                </a>
            </li>
            <li>
                <a class="block border border-filterborder py-3 px-4 rounded-lg mb-2 hover:bg-filterborder ease-in-out duration-300">
                    <img class="inline-block" src="{{asset('assets/img/payment-3.png')}}" />
                    <p class="inline-block ml-4 font-normal text-sm text-title">Pay In 4. No Interest, No Fees.</p>
                </a>
            </li>
        </ul>
    </div>
</section>




<section class="descriptions pb-24">
    <div class="container">
        <div class="xl:flex xl:flex-row">
            <div class="xl:basis-8/12">
                <div class="hidden xl:block py-5 px-6 bg-filterbackground border border-filterborder rounded-xl">
                    <img class="rtl:float-right  rtl:ml-8  float-left mr-8 my-2" src="{{asset('assets/img/logo.svg')}}" />
                    <ul>
                        <li class="inline-block w-4/12 font-semibold text-base text-title mb-2">
                            <img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" /> 
                            {{__('apartment.num_beds'). ' ( '.$apartment->num_beds}} ) </li>
                        <li class="inline-block w-4/12 font-semibold text-base text-title mb-2">
                            <img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" /> 
                            {{__('apartment.floor_number'). ' ( '.$apartment->floor_number .' ) ' . __('apartment.unit_number'). ' ( '.$apartment->unit_number }} )
                        </li>
                        <li class="inline-block w-4/12 font-semibold text-base text-title mb-2">
                            <img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" />
                            {{__('apartment.bathrooms_count'). ' ( '.$apartment->bathrooms_count}} ) 
                        </li>
                        <li class="inline-block w-4/12 font-semibold text-base text-title mb-2">
                            <img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" /> 
                            {{__('apartment.num_rooms'). ' ( '.$apartment->num_rooms }} ) 
                        </li>
                         
                    </ul>
                    <div class="clear-both"></div>
                </div>
                <div class="py-2 xl:py-7 detail-description border-b border-blackopacity mb-8">
                    <h4 class="font-semibold text-xl text-title">   
                        {{__('apartment.description')}}
                    </h4>
                    <p class="font-light text-base text-gri mt-3 mb-2 ease-in-out duration-900 max-h-[72px] overflow-hidden">
                        {!! $apartment->ml('description') !!}         
                    </p>
                    {{-- <button class="showmore font-normal text-sm text-blue underline">Read More</button> --}}
                </div>
                <div class="tabs" id="tabs">
                    <ul class="buttons w-[210vw] xl:w-auto">
                        <li class="inline-block">
                            <a class="xl:px-5 xl:py-3 rounded-lg rtl:ml-2 mr-2 block bg-price" href="#tabs-1">
                                <svg class="hidden -translate-y-0.5 xl:inline-block" id="building" xmlns="http://www.w3.org/2000/svg" width="17.371" height="18.707" viewBox="0 0 17.371 18.707">
                                    <path id="Path_1364" data-name="Path 1364" d="M15.354,4H8A2,2,0,0,0,6,6V20.7a2,2,0,0,0,2,2H21.367a2,2,0,0,0,2-2V13.354a2,2,0,0,0-2-2H17.358V6A2,2,0,0,0,15.354,4ZM6.668,20.7V6A1.336,1.336,0,0,1,8,4.668h7.349A1.336,1.336,0,0,1,16.69,6V22.039H14.017V17.7a.334.334,0,0,0-.334-.334H9.675a.334.334,0,0,0-.334.334v4.343H8A1.336,1.336,0,0,1,6.668,20.7Zm3.341,1.336V18.031h3.341v4.009ZM21.367,12.017A1.336,1.336,0,0,1,22.7,13.354V20.7a1.336,1.336,0,0,1-1.336,1.336H17.358V12.017Z" transform="translate(-6 -4)" fill="currentColor"/>
                                    <path id="Path_1365" data-name="Path 1365" d="M12.334,12H13.67A.334.334,0,0,0,14,11.67V10.334A.334.334,0,0,0,13.67,10H12.334a.334.334,0,0,0-.334.334V11.67A.334.334,0,0,0,12.334,12Zm.334-1.336h.668v.668h-.668Zm-.334,4.677H13.67A.334.334,0,0,0,14,15.011V13.675a.334.334,0,0,0-.334-.334H12.334a.334.334,0,0,0-.334.334v1.336A.334.334,0,0,0,12.334,15.345Zm.334-1.336h.668v.668h-.668Zm1,4.677A.334.334,0,0,0,14,18.352V17.015a.334.334,0,0,0-.334-.334H12.334a.334.334,0,0,0-.334.334v1.336a.334.334,0,0,0,.334.334Zm-1-1.336h.668v.668h-.668ZM17.679,12h1.336a.334.334,0,0,0,.334-.334V10.334A.334.334,0,0,0,19.015,10H17.679a.334.334,0,0,0-.334.334V11.67A.334.334,0,0,0,17.679,12Zm.334-1.336h.668v.668h-.668Zm-.334,4.677h1.336a.334.334,0,0,0,.334-.334V13.675a.334.334,0,0,0-.334-.334H17.679a.334.334,0,0,0-.334.334v1.336A.334.334,0,0,0,17.679,15.345Zm.334-1.336h.668v.668h-.668Zm-.334,4.677h1.336a.334.334,0,0,0,.334-.334V17.015a.334.334,0,0,0-.334-.334H17.679a.334.334,0,0,0-.334.334v1.336A.334.334,0,0,0,17.679,18.686Zm.334-1.336h.668v.668h-.668Zm5.679,2h1.336a.334.334,0,0,0,.334-.334V17.683a.334.334,0,0,0-.334-.334H23.692a.334.334,0,0,0-.334.334V19.02A.334.334,0,0,0,23.692,19.354Zm.334-1.336h.668v.668h-.668Zm-.334,4.677h1.336a.334.334,0,0,0,.334-.334V21.024a.334.334,0,0,0-.334-.334H23.692a.334.334,0,0,0-.334.334V22.36A.334.334,0,0,0,23.692,22.694Zm.334-1.336h.668v.668h-.668Z" transform="translate(-9.996 -7.996)" fill="currentColor"/>
                                </svg>
                                <span class="font-semibold">
                                    {{__('apartment.specifications')}}
                                </span>
                            </a>
                        </li>
                        <li class="inline-block">
                            <a class="xl:px-5 xl:py-3 rounded-lg rtl:ml-2 mr-2 block" href="#tabs-2">
                                <svg class="hidden -translate-y-0.5 xl:inline-block" xmlns="http://www.w3.org/2000/svg" width="20.671" height="19.707" viewBox="0 0 20.671 19.707">
                                    <path id="Icon_feather-star" data-name="Icon feather-star" d="M12.836,3l3.039,6.157,6.8.993-4.918,4.79,1.161,6.767-6.078-3.2-6.078,3.2L7.918,14.94,3,10.151l6.8-.993Z" transform="translate(-2.5 -2.5)" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
                                </svg>
                                <span class="font-semibold">
                                    {{__('apartment.total_reviews').' ( '.$apartment->reviews->count()}} )
                                </span>
                            </a>
                        </li>
                        <li class="inline-block">
                            <a class="xl:px-5 xl:py-3 rounded-lg rtl:ml-2 mr-2 block" href="#tabs-3">
                                <svg class="hidden -translate-y-0.5 xl:inline-block" xmlns="http://www.w3.org/2000/svg" width="16.306" height="19.707" viewBox="0 0 16.306 19.707">
                                    <g id="Icon_feather-map-pin" data-name="Icon feather-map-pin" transform="translate(0.5 0.5)">
                                        <path id="Path_1362" data-name="Path 1362" d="M19.806,9.153c0,5.952-7.653,11.054-7.653,11.054S4.5,15.105,4.5,9.153a7.653,7.653,0,1,1,15.306,0Z" transform="translate(-4.5 -1.5)" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
                                        <path id="Path_1363" data-name="Path 1363" d="M18.6,13.051A2.551,2.551,0,1,1,16.051,10.5,2.551,2.551,0,0,1,18.6,13.051Z" transform="translate(-8.398 -5.398)" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"/>
                                    </g>
                                </svg>
                                <span class="font-semibold">
                                    {{__('apartment.location')}}
                                </span>
                            </a>
                        </li>
                        <li class="inline-block">
                            <a class="xl:px-5 xl:py-3 rounded-lg rtl:ml-2 mr-2 block" href="#tabs-4">
                                <svg class="hidden -translate-y-0.5 xl:inline-block" xmlns="http://www.w3.org/2000/svg" width="16.734" height="18" viewBox="0 0 16.734 18">
                                    <path fill="currentColor" d="M40.372,2.813h6.715a.264.264,0,0,0,0-.527H40.372a.264.264,0,0,0,0,.527Zm0,3.164h6.715a.264.264,0,1,0,0-.527H40.372a.264.264,0,0,0,0,.527Zm0-1.582h6.715a.264.264,0,1,0,0-.527H40.372a.264.264,0,0,0,0,.527ZM52.5,3.4l-.373-.373a.791.791,0,0,0-1.119,0l-1.23,1.23V1.318A1.32,1.32,0,0,0,48.458,0H39a1.32,1.32,0,0,0-1.318,1.318V15.012H36.259a.264.264,0,0,0-.264.264v1.406A1.32,1.32,0,0,0,37.313,18h11.18l.029,0a1.32,1.32,0,0,0,1.255-1.317V7.237L52.5,4.515a.792.792,0,0,0,0-1.119ZM37.313,17.473a.792.792,0,0,1-.791-.791V15.539H47.034v1.09a1.364,1.364,0,0,0,.292.844Zm11.936-2.2s0,0,0,0v1.354a.844.844,0,1,1-1.687,0V15.275a.264.264,0,0,0-.264-.264H38.21V1.318A.792.792,0,0,1,39,.527h9.457a.792.792,0,0,1,.791.791V4.781L44.362,9.668h-3.99a.264.264,0,0,0,0,.527h3.463L42.8,11.227l-.019.022H40.372a.264.264,0,0,0,0,.527H42.59l-.352,1.055H40.372a.264.264,0,0,0,0,.527h1.969a.264.264,0,0,0,.057-.006.255.255,0,0,0,.116-.011l1.678-.559.005,0a.263.263,0,0,0,.045-.021l.007,0,.018-.012.006,0,.022-.019.941-.941h1.851a.264.264,0,0,0,0-.527H45.763l3.486-3.486ZM43.1,11.9l.515.515-.773.258Zm1,.258-.746-.746L49.7,5.077h0l.689-.689.746.746Zm8.017-8.017-.617.617-.746-.746.617-.617a.264.264,0,0,1,.373,0l.373.373a.264.264,0,0,1,0,.373Z" transform="translate(-35.995)"/>
                                </svg>
                                <span class="font-semibold">
                                    {{__('apartment.terms_policies')}}
                                </span>
                            </a>
                        </li>
                    </ul>
                    <div class="sections">
                        <div class="pt-8" id="tabs-1">
                            <h5 class="font-semibold text-xl text-filterhover mb-6">
                                {{__('apartment.specifications_title')}}
                            </h5>
                            <ul>
                                @foreach ($apartment->features as $item)
                                    <li class="inline-block mb-6 w-full xl:w-4/12 hover:text-price ease-in-out duration-300 cursor-pointer">
                                        <img class="inline-block rtl:ml-2 mr-2" width="20" height="20" 
                                        src="{{getImage($item,'icon')}}" />
                                        <p class="inline-block ml-4">
                                            {{  $item->{'name_'.app()->getLocale()}  }}
                                        </p>
                                    </li>
                                @endforeach
                                
                                
                            </ul>
                            {{-- <button class="show-specifications font-semibold text-base border border-black rounded-full py-2 px-6">
                                Show All 30 Amenities
                            </button> --}}
                        </div>
                        <div class="pt-8" id="tabs-2">
                            <h5 class="font-semibold text-xl text-filterhover mb-6">
                                {{__('apartment.reviews_title')}}
                            </h5>
                            <ul>
                                @foreach ($apartment->reviews as $item)
                                <li class="bg-sort border border-filteritem rounded-lg p-5 mb-4">
                                    <div>
                                        <div class="w-10 h-10 rounded-full rtl:ml-4 mr-4 float-left rtl:float-right inline-block" style="background-image: url({{asset('assets/img/slider.png')}}"></div>
                                        <h5 class="font-normal text-base">  
                                            {{$item->customer->first_name.' '.$item->customer->last_name}}
                                        </h5>
                                        <p class="font-normal text-xs text-filterhover">
                                            
                                        </p>
                                    </div>
                                    <div class="my-3">
                                        @for ($i=0; $i < $item->rating; $i++) 
                                            <img class="inline-block" src="{{asset('assets/img/comment-star.svg')}}" />
                                        @endfor
                                        
                                        <p class="inline-block ml-3 translate-y-0.5 font-normal text-base">
                                            {{$item->created_at?->diffForHumans()}}
                                        </p>
                                    </div>
                                    <p class="font-light text-base text-black"> 
                                        {{$item->review_text}}
                                    </p>
                                </li>
                                @endforeach
                              
                               
                            </ul>
                            {{-- <button class="show-specifications font-semibold text-base border border-black rounded-full py-2 px-6">Show All 30 Amenities</button> --}}
                        </div>
                        <div class="pt-8" id="tabs-3">
                            <h5 class="font-semibold text-xl text-filterhover mb-6">    
                                {{__('apartment.where_us')}}
                            </h5>
                             
                            <div class="h-52 lg:h-96 rounded-xl overflow-hidden" id="map">
                                {!! $apartment->building?->map !!}
                            </div>
                        </div>
                        <div class="pt-8" id="tabs-4">
                            <h5 class="font-semibold text-xl text-filterhover mb-6">
                                {{__('apartment.terms_policies_title')}}
                            </h5>
                            {{-- <ul>
                                <li class="inline-block w-4/12 font-semibold text-base text-title mb-2"><img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" /> Free Cancellation For 48 Hours</li>
                                <li class="inline-block w-4/12 font-semibold text-base text-title mb-2"><img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" /> Free Cancellation For 48 Hours</li>
                                <li class="inline-block w-4/12 font-semibold text-base text-title mb-2"><img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" /> Dive Right In</li>
                                <li class="inline-block w-4/12 font-semibold text-base text-title mb-2"><img class="inline-block rtl:ml-2 mr-2" src="{{asset('assets/img/feature-ok.svg')}}" /> Dive Right In</li>
                            </ul> --}}
                            <h6 class="mt-8">
                                {{$apartment->policy?->{'name_'.app()->getLocale()} }}
                            </h6>
                            <p class="font-light text-base text-gri mt-3 mb-2 ease-in-out duration-900 max-h-[72px] overflow-hidden">
                                {!! $apartment->policy?->{'description_'.app()->getLocale()} !!}              
                            </p>
                         </div>
                    </div>
                </div>
            </div>
            <div class="hidden xl:block xl:basis-4/12 rtl:xl:pr-5 xl:pl-5">
                <div class="border border border-filterborder rounded-xl px-5 py-6">
                    <p class="font-normal text-base text-reviews">
                        <span class="font-bold text-2xl text-black translate-y-0.5 inline-block">
                            {{$apartment->price}} 
                        </span> 
                        {{__('apartment.sar')}}
                    </p>
                    <form action="{{ route('web-booking.determine',$apartment->id) }}" class="mb-9 space-y-4" method="GET">
             
                        <div class="flex flex-wrap -mx-2">
                            <div class="flex flex-col w-1/2 px-2">
                                <label for="checkin" class="mb-1 font-semibold">@lang('apartment.checkin_date')</label>
                                <input type="date" id="checkin" name="checkin" class="bg-blackopacity border border-gray-300 rounded-lg h-12 px-3" required
                                    value="{{$started_day}}">
                            </div>
                        
                            <div class="flex flex-col w-1/2 px-2">
                                <label for="checkout" class="mb-1 font-semibold">@lang('apartment.checkout_date')</label>
                                <input type="date" id="checkout" name="checkout" class="bg-blackopacity border border-gray-300 rounded-lg h-12 px-3" required
                                    value="{{ $next_started_day }}">
                            </div>
                        </div>
                 
                        
                    
                        {{-- <div class="flex flex-wrap -mx-2">
                            <div class="flex flex-col w-1/2 px-2">
                                <label for="adults" class="mb-1 font-semibold">@lang('apartment.adults_count')</label>
                                <input type="number" 
                                       id="adults" 
                                       name="adults_count" 
                                       min="1" 
                                       max="{{$apartment->adults_count}}" 
                                       value="{{$apartment->adults_count}}" 
                                       class="border border-gray-300 rounded-lg h-12 px-3" 
                                       required
                                       oninput="validateInput(this, '{{__('apartment.min_children')}}', '{{__('apartment.max_adults').' '.$apartment->adults_count}}')">

                            </div>
                        
                            <div class="flex flex-col w-1/2 px-2">
                                <label for="children" class="mb-1 font-semibold">@lang('apartment.children_count')</label>
                                <input type="number" 
                                       id="children" 
                                       name="children_count" 
                                       min="0" 
                                       max="{{$apartment->children_count}}" 
                                       value="{{$apartment->children_count}}" 
                                       class="border border-gray-300 rounded-lg h-12 px-3" 
                                       oninput="validateInput(this, '{{__('apartment.min_children')}}', '{{__('apartment.max_children').' '.$apartment->children_count}}')">
                            </div>
                        </div> --}}
                        
                            <script>
                            function validateInput(input, minMessage, maxMessage) {
                                if (input.validity.rangeUnderflow) {
                                    input.setCustomValidity(minMessage);  
                                } else if (input.validity.rangeOverflow) {
                                    input.setCustomValidity(maxMessage);   
                                } else {
                                    input.setCustomValidity('');  
                                }
                            }
                            </script>
                        
                        {{-- <div class="flex flex-col">
                            <label for="coupon_code" class="mb-1 font-semibold">@lang('apartment.coupon_code')</label>
                            <input type="text" id="coupon_code" name="coupon_code" class="border border-gray-300 rounded-lg h-12 px-3">
                            <button type="button" id="verify_coupon" class="bg-price rounded-lg h-12 w-full font-semibold text-white mt-4">
                                تحقق من الكوبون
                            </button>
                            <div id="coupon_message" class="mt-2 text-red-500"></div>
                        </div> --}}
                        
                        {{-- <ul>
                            @foreach (config('payments.gateways') as $index => $item)
                                <li>
                                    <label class="block border border-filterborder py-3 px-4 rounded-lg mb-2 hover:bg-filterborder ease-in-out duration-300 cursor-pointer">
                                        <input type="radio" name="payment_method_code" value="{{ $item['value'] }}" class="hidden" /> 
                                        <img class="inline-block" src="{{ asset('images/' . $item['icon'] . '.svg') }}" alt="{{ $item['value'] }}" />
                                        <p class="inline-block ml-4 font-normal text-sm text-title">
                                            {{ $item['value'] }}
                                        </p>
                                    </label>
                                </li>
                            @endforeach
                        </ul> --}}
                         
                        <ul>
                            <li class="mb-4 font-semibold text-sm text-title">
                                <span>
                                    {{__('apartment.one_night')}}
                                </span>
                                <span class="float-right rtl:float-left">
                                    {{$apartment->price . ' ' . __('apartment.price')}} 
                                </span>
                                <div class="clear-both"></div>
                            </li>
                            <li class="mb-4 font-semibold text-sm text-title">
                                <span>{{ __('apartment.total_nights') }}</span>
                                <span class="float-right rtl:float-left" id="totalNights">1 {{ __('apartment.nights') }}</span>
                                <div class="clear-both"></div>
                            </li>
                            {{-- <li class="mb-4 font-semibold text-sm text-title">
                                <span>{{ __('apartment.discounted_cost') }}</span>
                                <span class="float-right rtl:float-left" id="discounted_cost">
                                    0.00 {{ __('apartment.price') }}
                                </span>
                                <div class="clear-both"></div>
                            </li> --}}
                            <li class="mb-4 font-semibold text-sm text-title">
                                <span>{{ __('apartment.total_cost') }}</span>
                                <span class="float-right rtl:float-left" id="totalCost"> {{$apartment->price .' '.__('apartment.price') }} </span>
                                <div class="clear-both"></div>
                            </li>
                            
                            
                            
                        </ul>
                        @if ($errors->any())
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                            <strong class="font-bold">حدث خطأ!</strong>
                            <span class="block sm:inline">
                                @foreach ($errors->all() as $error)
                                    {{ $error }}
                                @endforeach
                            </span>
                             
                        </div>
                        @endif
                        <button type="submit" class="bg-price rounded-lg h-12 w-full font-semibold text-white">@lang('apartment.book_now')</button>
                    </form>
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
</section>
{{-- @dd($apartment->booked_days($apartment->bookings)); --}}
@endsection
@push('js')
@include('customer.section.script-form')
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    function toggleFavorite(apartmentId) {
        $.ajax({
            url: '{{ route('customer.toggle.favorite') }}',
            type: 'POST',
            data: {
                apartment_id: apartmentId,
                _token: '{{ csrf_token() }}'
            },
            success: function(data) {
                if (data.success) {
                    let icon = $('#favorite-icon-' + apartmentId);
                    if (data.action === 'added') {
                        icon.attr('src', '{{ asset("assets/img/favorited.svg") }}');  
                        Swal.fire({
                            icon: 'success',
                            title: '{{ __("apartment.favorite_added") }}',
                            text: data.message,
                            timer: 1500,
                            showConfirmButton: false
                        });
                    } else {
                        icon.attr('src', '{{ asset("assets/img/favoritee.svg") }}'); 
                        Swal.fire({
                            icon: 'info',
                            title: '{{ __("apartment.favorite_removed") }}',
                            text: data.message,
                            timer: 1500,
                            showConfirmButton: false
                        });
                    }
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: '{{ __("apartment.favorite_failed") }}',
                        text: data.message || '{{ __("apartment.favorite_failed") }}'
                    });
                }
            },
            error: function(xhr, status, error) {
                if (xhr.status === 401) {
                    Swal.fire({
                        icon: 'error',
                        title: '{{__("apartment.favorite_login_title")}}',
                        text: '{{ __("apartment.favorite_login") }}'
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: '{{ __("apartment.favorite_failed") }}'
                    });
                    console.error('Error:', error);
                }
            }
        });
    }
    const nightlyRate = {{ $apartment->price }};
    let discount = 0;

    function calculateNightsAndCost() {
        const checkin = new Date($('#checkin').val());
        const checkout = new Date($('#checkout').val());
        const timeDifference = checkout - checkin;
        const nights = timeDifference / (1000 * 60 * 60 * 24);
        if (nights > 0) {
            const totalCost = nights * nightlyRate;
            $('#totalNights').text(nights + ' ' + "{{ __('apartment.nights') }}");
            let finalCost = totalCost;
            if (discount > 0) {
                finalCost = totalCost - (totalCost * (discount / 100));  
            }
            $('#totalCost').text(finalCost.toFixed(2) + ' ' + "{{ __('apartment.price') }}");
            if (discount > 0) {
                $('#discountedCost').text("{{ __('apartment.discounted_price') }}: " + finalCost.toFixed(2) + ' ' + "{{ __('apartment.price') }}");
            } else {
                $('#discountedCost').text('');
            }
        } else {
            $('#totalNights').text(0);
            $('#totalCost').text('0.00');
            $('#discountedCost').text('');
        }
    }

    $(document).ready(function() {
        // Calculate nights and cost on date change
        $('#checkin, #checkout').on('change', calculateNightsAndCost);

        $("#booking").validate({
            rules: {
                checkin: "required",
                checkout: {
                    required: true,
                    greaterThan: "#checkin"
                },
                adults_count:{
                    required: true,
                    min: 1,
                    max: "{{$apartment->adults_count}}"
                },
                children_count:{
                    required: true,
                    min: 0,
                    max: {{$apartment->children_count}}
                }
                
            },
            messages: {
                checkin: "{{__('apartment.checkin_required')}}",
                checkout: {
                    required: "{{__('apartment.checkout_required')}}",
                    greaterThan: "{{__('apartment.checkout_greater_than')}}"
                },
                adults_count:{
                    required: "{{__('apartment.adults_count_required')}}",
                    min: "{{__('apartment.adults_count_min')}}",
                    max: "{{__('apartment.adults_count_max')}}"
                },
                children_count:{
                    required: "{{__('apartment.children_count_required')}}",
                    min: "{{__('apartment.children_count_min')}}",
                    max: "{{__('apartment.children_count_max')}}"
                }
            },
            submitHandler: function(form) {
                HoldOn.open({
                    theme: "sk-cube-grid",  
                    message: "{{__('apartment.loading_message')}}"  
                });
                var apartment_id = $('#apartment_id').val();
                $.ajax({
                   
                    url: "{{ route('web-booking.determine',"+apartment_id+") }}",  
                    method: "POST",
                    data: $(form).serialize(), 
                    success: function(response) {
                        HoldOn.close();
                        Swal.fire({
                            icon: 'success',
                            title: "{{__('apartment.success')}}",
                            text: "{{__('apartment.booking_success_message')}}",
                            button: true,
                        });
                        location.reload();
                    },
                    error: function(xhr) {
                        HoldOn.close();
                        Swal.fire({
                            icon: 'error',
                            title: "{{__('apartment.error')}}",
                            text: "{{__('apartment.booking_failed_message')}}",
                            button: true,
                        });
                    }
                });
            }
        });
    });

    const bookedDays = @json($apartment->booked_days($apartment->bookings));
    console.log(bookedDays);
    console.log(typeof flatpickr); 

    function initializeDatePicker(selector) {
        if (typeof flatpickr === "undefined") {
            console.error("flatpickr library is not loaded.");
            return;
        }

        flatpickr(selector, {
            dateFormat: "Y-m-d",
            minDate: "today",
            allowInput: false,  
            disable: bookedDays.length > 0 ? bookedDays : [],   
            onDayCreate: function(dObj, dStr, fp, dayElem) {
                const dateStr = dayElem.dateObj.toISOString().split('T')[0];
                if (bookedDays.includes(dateStr)) { 
                    dayElem.style.backgroundColor = "#0000001a";  
                    dayElem.style.color = "#fff";  
                    dayElem.classList.add("flatpickr-disabled");  
                } else {
                    dayElem.style.backgroundColor = "#fff"; 
                    dayElem.style.color = "#000"; 
                }
            },
            onChange: function(selectedDates, dateStr, instance) {
                if (instance.calendarContainer) {
                    instance.calendarContainer.querySelectorAll(".flatpickr-day").forEach(dayElem => {
                        const dateStr = dayElem.dateObj.toISOString().split('T')[0];
                        if (bookedDays.includes(dateStr)) {
                            dayElem.style.backgroundColor = "#0000001a";  
                            dayElem.style.color = "#000";  
                        } else {
                            dayElem.style.backgroundColor = "#fff"; 
                            dayElem.style.color = "#000"; 
                        }
                    });
                }
                if (selectedDates.length > 0 && instance.calendarContainer) {
                    const selectedDayElem = instance.calendarContainer.querySelector(`.flatpickr-day[aria-label="${selectedDates[0].toDateString()}"]`);
                    if (selectedDayElem) {
                        selectedDayElem.style.backgroundColor = "#0000001a";
                        selectedDayElem.style.color = "#fff";
                    }
                }
            }
        });
    }

    document.addEventListener("DOMContentLoaded", function() {
        initializeDatePicker("#checkin");
        initializeDatePicker("#checkout");
    });


    document.addEventListener('DOMContentLoaded', function() {
        const checkinInput = document.getElementById('checkin');
        const checkoutInput = document.getElementById('checkout');
        checkinInput.addEventListener('change', function() {
            const checkinDate = new Date(this.value);
            const minCheckoutDate = new Date(checkinDate);
            minCheckoutDate.setDate(minCheckoutDate.getDate() + 1);
            const year = minCheckoutDate.getFullYear();
            const month = String(minCheckoutDate.getMonth() + 1).padStart(2, '0');
            const day = String(minCheckoutDate.getDate()).padStart(2, '0');
            const formattedDate = `${year}-${month}-${day}`;
            checkoutInput.value = formattedDate;
            checkoutInput.min = formattedDate;
        });
    });
</script> 
@endpush
